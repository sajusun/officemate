var X=Object.defineProperty;var ee=(m,g,x)=>g in m?X(m,g,{enumerable:!0,configurable:!0,writable:!0,value:x}):m[g]=x;var k=(m,g,x)=>ee(m,typeof g!="symbol"?g+"":g,x);(function(){"use strict";function m(o,t,e){const n=t.recipientName||"Team",i=e.userFullName||"Best",r=e.userJobTitle||"",c=`

Best regards,
${i}${r?`
${r}`:""}`;switch(o){case"polite_pushback":return`Hi ${n},

Thank you for reaching out and sharing the updated requirements.

While I understand the urgency of this deliverable, our team is currently committed to existing high-priority milestones. Taking on this additional scope at this time would compromise the quality and delivery schedule of our core commitments.

I recommend we either:
1. Schedule this for our upcoming sprint/cycle starting next week, or
2. Re-prioritize our current backlog so we can allocate dedicated focus.

Let me know which option aligns best with your roadmap.${c}`;case"executive_status":return`Hi ${n},

Please find below our weekly executive status update:

• Completed Deliverables:
  - Finalized system review and stakeholder alignment.
  - Resolved all critical path items for the current phase.

• Currently In Progress:
  - Quality assurance testing and documentation wrap-up.
  - Coordinating with cross-functional partners for deployment.

• Blockers & Risks:
  - None at this time. All milestones remain on track.

• Next Steps:
  - Review meeting scheduled for Thursday to finalize launch readiness.

Please let me know if you require any additional metrics or details.${c}`;case"formal_confirmation":return`Hi ${n},

Thank you for the productive discussion. 

I am writing to formally confirm our alignment on the agreed action items and timeline:
• Scope: ${t.keyPoints||"As discussed in our meeting"}
• Target Delivery Date: ${t.deadline||"End of week"}

Our team has initiated the next steps and we will share progress checkpoints accordingly. If there are any revisions needed, please feel free to flag them by EOD tomorrow.${c}`;case"friendly_followup":return`Hi ${n},

Hope you are having a productive week!

I wanted to quickly circle back regarding our previous discussion on ${t.keyPoints||"the project proposal"}. 

When you have a moment, could you please share a quick update or let me know if you need any additional inputs from my end to move forward?

Looking forward to hearing from you.${c}`;case"meeting_reschedule":return`Hi ${n},

I hope you are doing well.

Due to an unavoidable scheduling conflict with an executive client briefing, I will need to request rescheduling our meeting scheduled for today.

Would any of the following alternate time slots work on your calendar?
• Tomorrow at 11:00 AM EST
• Thursday at 2:30 PM EST
• Friday at 10:00 AM EST

My sincere apologies for any inconvenience this may cause, and thank you for your flexibility.${c}`;default:return`Hi ${n},

Thank you for the update. Everything looks aligned from our perspective.

Please let me know if you need any further assistance.${c}`}}async function g(o,t,e){var i,r,c,u,p,h,a,d;if(e.aiProvider==="offline"||!e.aiApiKey)return m(o,t,e);const n=`You are OfficeMate, an expert Microsoft 365 executive email assistant.
Write a professional corporate email response.
Tone: ${o.replace("_"," ").toUpperCase()}
Sender: ${e.userFullName} (${e.userJobTitle} at ${e.companyName})
Recipient: ${t.recipientName||"Colleague / Client"}
Context / Incoming Email:
"${t.incomingText||"Follow up on project status"}"
Key Points to Include:
"${t.keyPoints||"Confirm timeline and align on next steps"}"

Guidelines:
- Clear, concise, executive tone.
- Professional corporate etiquette.
- Include a polite sign-off with the sender's name and title.`;try{if(e.aiProvider==="openai"){const l=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e.aiApiKey}`},body:JSON.stringify({model:e.aiModel||"gpt-4o-mini",messages:[{role:"user",content:n}],temperature:.3})});if(!l.ok)throw new Error(l.statusText);return((c=(r=(i=(await l.json()).choices)==null?void 0:i[0])==null?void 0:r.message)==null?void 0:c.content)||m(o,t,e)}if(e.aiProvider==="gemini"){const l=e.aiModel||"gemini-1.5-flash",f=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${l}:generateContent?key=${e.aiApiKey}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:n}]}]})});if(!f.ok)throw new Error(f.statusText);return((d=(a=(h=(p=(u=(await f.json()).candidates)==null?void 0:u[0])==null?void 0:p.content)==null?void 0:h.parts)==null?void 0:a[0])==null?void 0:d.text)||m(o,t,e)}}catch(l){return console.warn("AI API call failed, falling back to corporate template",l),m(o,t,e)}return m(o,t,e)}function x(o){const t=o.split(new RegExp("(?<=[.?!])\\s+|\\n+")).map(i=>i.trim()).filter(i=>i.length>10),e=/\b(will|shall|action|deadline|by\s+[A-Za-z]+|assigned|due|finalize|submit|deliver|schedule|prepare|complete|follow\s+up)\b/i,n=[];return t.forEach(i=>{if(e.test(i)&&n.length<10){let r;const c=i.match(/@([A-Za-z]+)/);c&&(r=c[1]);let u;const p=i.match(/\bby\s+([A-Za-z0-9\s,]+)(?=[.?!]|$)/i);p&&(u=p[1].trim()),n.push({id:"act_"+Math.random().toString(36).substring(2,9),text:i,assignee:r,dueDate:u,completed:!1})}}),n}function $(o){function t(s,b){return s>>>b|s<<32-b}const e=Math.pow,n=e(2,32),i="length";let r,c,u="";const p=[],h=o[i]*8,a=[],d=[];let l=0;const f={};for(let s=2;l<64;s++)if(!f[s]){for(r=0;r<313;r+=s)f[r]=!0;a[l]=e(s,.5)*n|0,d[l++]=e(s,1/3)*n|0}for(o+="";o[i]%64-56;)o+="\0";for(r=0;r<o[i];r++)c=o.charCodeAt(r),p[r>>2]|=c<<(3-r)%4*8;for(p[p[i]]=h/n|0,p[p[i]]=h,c=0;c<p[i];){const s=p.slice(c,c+=16),b=a.slice(0,8);for(r=0;r<64;r++){const v=s[r-15],I=s[r-2],T=a[0],E=a[4],j=a[7]+(t(E,6)^t(E,11)^t(E,25))+(E&a[5]^~E&a[6])+d[r]+(s[r]=r<16?s[r]:s[r-16]+(t(v,7)^t(v,18)^v>>>3)+s[r-7]+(t(I,17)^t(I,19)^I>>>10)|0),Z=(t(T,2)^t(T,13)^t(T,22))+(T&a[1]^T&a[2]^a[1]&a[2]);a[7]=a[6],a[6]=a[5],a[5]=a[4],a[4]=a[3]+j|0,a[3]=a[2],a[2]=a[1],a[1]=a[0],a[0]=j+Z|0}for(r=0;r<8;r++)a[r]=a[r]+b[r]|0}for(r=0;r<8;r++)for(let s=3;s>=0;s--){const b=a[r]>>s*8&255;u+=(b<16?"0":"")+b.toString(16)}return u}const R="OM_#2pQ9!",B="@zXc4$bN";function K(o,t){const e=o.trim().toUpperCase();return $(`${R}:${e}:${B}:${t}`)}function H(o,t){if(!o.isPro)return{isValid:!0,sanitized:o};if(!o.proLicenseKey||!o.proAuthSig||!t)return{isValid:!1,sanitized:{...o,isPro:!1,proLicenseKey:"",proAuthSig:void 0}};const e=K(o.proLicenseKey,t);return o.proAuthSig!==e?{isValid:!1,sanitized:{...o,isPro:!1,proLicenseKey:"",proAuthSig:void 0}}:{isValid:!0,sanitized:o}}const S="officemate_settings",A="officemate_workspaces",L="officemate_notes",z=3;function M(){return new Date().toISOString().split("T")[0]}const W={isPro:!1,aiProvider:"offline",userFullName:"Alex Mercer",userJobTitle:"Senior Product Lead",companyName:"Enterprise Solutions",emailSignature:`Best regards,
Alex Mercer
Senior Product Lead`,freeDraftsUsedToday:0,lastDraftDate:M()},P="officemate_device_id";async function U(){return new Promise(o=>{chrome.storage.local.get([P],t=>{let e=t[P];if(!e){const n=[typeof navigator<"u"?navigator.userAgent:"",typeof navigator<"u"?navigator.language:"",typeof screen<"u"?`${screen.width}x${screen.height}`:"",Date.now().toString(),Math.random().toString(36).substring(2)].join("|");e="om-dev-"+$(n).substring(0,16),chrome.storage.local.set({[P]:e})}o(e)})})}async function y(){const o=await U();return new Promise(t=>{chrome.storage.local.get([S],e=>{let n=e[S]||{...W};const{isValid:i,sanitized:r}=H(n,o);i||chrome.storage.local.set({[S]:r});const c=M();r.lastDraftDate!==c&&(r.lastDraftDate=c,r.freeDraftsUsedToday=0,chrome.storage.local.set({[S]:r})),t(r)})})}async function F(o){const e={...await y(),...o};return new Promise(n=>{chrome.storage.local.set({[S]:e},()=>n(e))})}async function D(){const o=await y();if(o.isPro)return{allowed:!0,remaining:9999,isPro:!0};const t=Math.max(0,z-o.freeDraftsUsedToday);return{allowed:t>0,remaining:t,isPro:!1}}async function O(){const o=await y();return o.isPro?9999:(o.freeDraftsUsedToday+=1,await F(o),Math.max(0,z-o.freeDraftsUsedToday))}async function _(){return new Promise(o=>{chrome.storage.local.get([A],t=>{o(t[A]||[])})})}async function G(o){const e=(await _()).filter(n=>n.id!==o);return new Promise(n=>{chrome.storage.local.set({[A]:e},()=>n())})}async function C(){return new Promise(o=>{chrome.storage.local.get([L],t=>{o(t[L]||[])})})}async function J(o){const t=await C(),e=t.findIndex(n=>n.id===o.id);return e>=0?t[e]=o:t.unshift(o),new Promise(n=>{chrome.storage.local.set({[L]:t},()=>n())})}class V{constructor(t){k(this,"container",null);k(this,"shadow",null);k(this,"isOpen",!1);k(this,"currentTone","polite_pushback");k(this,"currentActionItems",[]);this.cssContent=t}init(){if(document.getElementById("officemate-root"))return;this.container=document.createElement("div"),this.container.id="officemate-root",this.shadow=this.container.attachShadow({mode:"open"});const t=document.createElement("style");t.textContent=this.cssContent,this.shadow.appendChild(t);const e=document.createElement("div");e.id="officemate-wrapper",this.shadow.appendChild(e),document.body.appendChild(this.container),this.renderPill(),this.renderSidebar(),this.initShortcuts()}showToast(t){if(!this.shadow)return;const e=document.createElement("div");e.className="om-toast",e.textContent=t,this.shadow.appendChild(e),setTimeout(()=>{e.style.opacity="0",e.style.transition="opacity 0.3s ease",setTimeout(()=>e.remove(),300)},2600)}renderPill(){if(!this.shadow)return;const t=this.shadow.getElementById("officemate-wrapper");if(!t)return;const e=document.createElement("div");e.className="officemate-pill",e.id="officemate-launch-pill",e.innerHTML=`
      <div class="pill-logo">OM</div>
      <span class="pill-text">OfficeMate</span>
      <span class="pill-badge">Copilot</span>
    `,e.addEventListener("click",()=>this.toggleSidebar()),t.appendChild(e)}async toggleSidebar(){if(!this.shadow)return;const t=this.shadow.getElementById("officemate-main-sidebar");if(t)if(this.isOpen=!this.isOpen,this.isOpen){t.classList.add("open");const e=await y(),n=this.shadow.getElementById("sidebar-pro-link");n&&(e.isPro?(n.textContent="👑 PRO",n.style.color="#a5b4fc",n.style.background="rgba(99,102,241,0.2)",n.style.borderColor="rgba(99,102,241,0.35)",n.removeAttribute("href")):(n.textContent="👑 Get Pro ↗",n.href="https://sajusun.gumroad.com/l/officemate-pro")),this.refreshWorkspaces(),this.refreshNotes()}else t.classList.remove("open")}renderSidebar(){var n,i,r,c,u,p,h;if(!this.shadow)return;const t=this.shadow.getElementById("officemate-wrapper");if(!t)return;const e=document.createElement("aside");e.className="officemate-sidebar",e.id="officemate-main-sidebar",e.innerHTML=`
      <div class="sidebar-header">
        <div class="sidebar-title-group">
          <div class="pill-logo" style="width: 22px; height: 22px; font-size: 10px;">OM</div>
          <span class="sidebar-title">OfficeMate Copilot</span>
          <a href="https://sajusun.gumroad.com/l/officemate-pro" target="_blank" id="sidebar-pro-link" style="font-size: 10px; font-weight: 700; color: #fbbf24; background: rgba(245,158,11,0.15); border: 1px solid rgba(245,158,11,0.3); padding: 2px 7px; border-radius: 4px; text-decoration: none; margin-left: 8px;">👑 Get Pro ↗</a>
        </div>
        <button class="close-btn" id="btn-close-sidebar">✕</button>
      </div>

      <nav class="sidebar-tabs">
        <button class="tab-btn active" data-tab="drafts">✉️ AI Drafts</button>
        <button class="tab-btn" data-tab="notes">📝 Meeting Notes</button>
        <button class="tab-btn" data-tab="workspace">🗂️ Workspaces</button>
      </nav>

      <div class="sidebar-body">
        <!-- Panel 1: AI Email Drafts -->
        <div class="panel active" id="panel-drafts">
          <span class="section-title">Select Professional Tone</span>
          <div class="tone-grid">
            <button class="tone-card active" data-tone="polite_pushback">🛡️ Polite Pushback</button>
            <button class="tone-card" data-tone="executive_status">📊 Status Update</button>
            <button class="tone-card" data-tone="formal_confirmation">🤝 Confirmation</button>
            <button class="tone-card" data-tone="friendly_followup">👋 Follow-Up</button>
            <button class="tone-card" data-tone="meeting_reschedule">📅 Reschedule</button>
          </div>

          <div style="display: flex; flex-direction: column; gap: 8px;">
            <label class="section-title">Incoming Email Context / Key Points</label>
            <textarea class="om-textarea" id="draft-context-input" rows="3" placeholder="Paste incoming email or write brief points..."></textarea>
          </div>

          <button class="om-btn primary" id="btn-generate-draft">
            <span>⚡ Generate Professional Draft</span>
          </button>

          <div style="display: flex; flex-direction: column; gap: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <span class="section-title">Draft Preview</span>
              <button class="om-btn" id="btn-copy-draft" style="font-size: 11px; height: 26px;">📋 Copy</button>
            </div>
            <div class="draft-preview-box" id="draft-output-preview" contenteditable="true">
              Click 'Generate Professional Draft' above to produce your response.
            </div>
          </div>
        </div>

        <!-- Panel 2: Meeting Notes & Actions -->
        <div class="panel" id="panel-notes">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span class="section-title">Action Items & Takeaways</span>
            <button class="om-btn" id="btn-grab-actions" style="font-size: 11px;">📌 Grab from Selection</button>
          </div>

          <div id="action-items-list" style="display: flex; flex-direction: column; gap: 6px;">
            <div style="color: #64748b; font-size: 12px; font-style: italic;">
              Highlight chat text or meeting notes and click "Grab from Selection".
            </div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 6px; margin-top: 10px;">
            <label class="section-title">Meeting Notes</label>
            <textarea class="om-textarea" id="meeting-notes-input" rows="5" placeholder="Key decisions, attendees, next steps..."></textarea>
          </div>

          <div style="display: flex; gap: 8px;">
            <button class="om-btn primary" id="btn-save-meeting-note" style="flex: 1;">Save Note</button>
            <button class="om-btn" id="btn-export-notes-md">Export .md</button>
          </div>

          <div id="saved-notes-history" style="display: flex; flex-direction: column; gap: 8px; margin-top: 12px;"></div>
        </div>

        <!-- Panel 3: Workspace Stash -->
        <div class="panel" id="panel-workspace">
          <div style="background: rgba(99,102,241,0.12); border: 1px solid rgba(99,102,241,0.3); border-radius: 8px; padding: 12px;">
            <strong style="color: #a5b4fc; font-size: 13px; display: block; margin-bottom: 4px;">Project Tab Stash</strong>
            <span style="font-size: 11.5px; color: #cbd5e1; line-height: 1.4;">
              Stash 15–30 open project tabs (Jira, Outlook, Confluence, GitHub) in 1 click to clear mental clutter & free RAM.
            </span>
          </div>

          <div style="display: flex; gap: 8px;">
            <input type="text" id="new-workspace-name" class="om-textarea" style="height: 36px; padding: 6px 12px;" placeholder="Workspace name (e.g. Client Alpha, Q3 Audit)">
            <button class="om-btn primary" id="btn-stash-current-tabs" style="white-space: nowrap;">⚡ Stash Tabs</button>
          </div>

          <span class="section-title">Saved Workspaces</span>
          <div id="workspaces-list" style="display: flex; flex-direction: column; gap: 10px;">
            <!-- Workspaces rendered dynamically -->
          </div>
        </div>
      </div>
    `,t.appendChild(e),(n=e.querySelector("#btn-close-sidebar"))==null||n.addEventListener("click",()=>this.toggleSidebar()),e.querySelectorAll(".tab-btn").forEach(a=>{a.addEventListener("click",()=>{var l;e.querySelectorAll(".tab-btn").forEach(f=>f.classList.remove("active")),e.querySelectorAll(".panel").forEach(f=>f.classList.remove("active")),a.classList.add("active");const d=a.getAttribute("data-tab");(l=e.querySelector(`#panel-${d}`))==null||l.classList.add("active")})}),e.querySelectorAll(".tone-card").forEach(a=>{a.addEventListener("click",()=>{e.querySelectorAll(".tone-card").forEach(d=>d.classList.remove("active")),a.classList.add("active"),this.currentTone=a.getAttribute("data-tone")})}),(i=e.querySelector("#btn-generate-draft"))==null||i.addEventListener("click",async()=>{const{allowed:a}=await D();if(!a){this.showToast("Daily free draft limit (3) reached! Upgrade to Pro on Gumroad for unlimited drafts.");return}const d=e.querySelector("#draft-context-input").value.trim(),l=e.querySelector("#draft-output-preview");l.textContent="Crafting executive response...";const f=await y(),s=await g(this.currentTone,{incomingText:d},f);l.textContent=s,await O(),this.showToast("Professional draft generated!")}),(r=e.querySelector("#btn-copy-draft"))==null||r.addEventListener("click",()=>{var d;const a=((d=e.querySelector("#draft-output-preview"))==null?void 0:d.textContent)||"";navigator.clipboard.writeText(a),this.showToast("Draft copied to clipboard!")}),(c=e.querySelector("#btn-grab-actions"))==null||c.addEventListener("click",()=>{var l;const a=(l=window.getSelection())==null?void 0:l.toString();if(!a){this.showToast("Please highlight text with your mouse first!");return}const d=x(a);if(d.length===0){this.showToast("No specific action items found in selection.");return}this.currentActionItems.push(...d),this.renderActionItemsList(),this.showToast(`Extracted ${d.length} action item(s)!`)}),(u=e.querySelector("#btn-save-meeting-note"))==null||u.addEventListener("click",async()=>{const a=e.querySelector("#meeting-notes-input").value.trim();if(!a&&this.currentActionItems.length===0)return;const d={id:"note_"+Date.now(),meetingTitle:document.title||"Meeting Notes",date:new Date().toLocaleDateString(),notes:a,actionItems:this.currentActionItems,timestamp:Date.now()};await J(d),e.querySelector("#meeting-notes-input").value="",this.currentActionItems=[],this.renderActionItemsList(),this.refreshNotes(),this.showToast("Meeting notes saved!")}),(p=e.querySelector("#btn-export-notes-md"))==null||p.addEventListener("click",async()=>{const a=await C();if(a.length===0){this.showToast("No meeting notes to export.");return}const d=`# OfficeMate Meeting Notes
Generated: ${new Date().toLocaleString()}

`+a.map(b=>`## ${b.meetingTitle} (${b.date})
${b.notes}

### Action Items:
`+b.actionItems.map(v=>`- [${v.completed?"x":" "}] ${v.text}`).join(`
`)).join(`

---

`),l=new Blob([d],{type:"text/markdown;charset=utf-8;"}),f=URL.createObjectURL(l),s=document.createElement("a");s.href=f,s.download=`Meeting_Notes_${Date.now()}.md`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(f),this.showToast("Exported to Markdown (.md)!")}),(h=e.querySelector("#btn-stash-current-tabs"))==null||h.addEventListener("click",()=>{const a=e.querySelector("#new-workspace-name"),d=a.value.trim()||`Workspace ${new Date().toLocaleDateString()}`;chrome.runtime.sendMessage({action:"STASH_TABS",name:d},l=>{l!=null&&l.success?(a.value="",this.refreshWorkspaces(),this.showToast(`Stashed ${l.count} tabs into "${d}"!`)):this.showToast((l==null?void 0:l.message)||"Failed to stash workspace.")})})}renderActionItemsList(){if(!this.shadow)return;const t=this.shadow.getElementById("action-items-list");if(t){if(this.currentActionItems.length===0){t.innerHTML='<div style="color: #64748b; font-size: 12px; font-style: italic;">No active action items. Highlight text above to add!</div>';return}t.innerHTML=this.currentActionItems.map((e,n)=>`
      <div style="display: flex; align-items: center; gap: 8px; background: #1e293b; padding: 6px 10px; border-radius: 6px; font-size: 12px;">
        <input type="checkbox" class="act-check" ${e.completed?"checked":""} data-idx="${n}">
        <span style="flex: 1; ${e.completed?"text-decoration: line-through; opacity: 0.5;":""}">${e.text}</span>
        <button class="close-btn act-del" data-idx="${n}" style="font-size: 12px; color: #ef4444;">✕</button>
      </div>
    `).join(""),t.querySelectorAll(".act-check").forEach(e=>{e.addEventListener("change",n=>{const i=Number(e.getAttribute("data-idx"));this.currentActionItems[i].completed=n.target.checked,this.renderActionItemsList()})}),t.querySelectorAll(".act-del").forEach(e=>{e.addEventListener("click",()=>{const n=Number(e.getAttribute("data-idx"));this.currentActionItems.splice(n,1),this.renderActionItemsList()})})}}async refreshWorkspaces(){if(!this.shadow)return;const t=this.shadow.getElementById("workspaces-list");if(!t)return;const e=await _();if(e.length===0){t.innerHTML='<div style="color: #64748b; font-size: 12px; text-align: center; padding: 20px 0;">No stashed workspaces yet. Type a name and click "Stash Tabs".</div>';return}t.innerHTML=e.map(n=>`
      <div class="workspace-card" data-ws-id="${n.id}">
        <div class="ws-header">
          <div class="ws-title">
            <span class="ws-color-dot" style="background: ${n.color||"#38bdf8"};"></span>
            <span>${n.name}</span>
          </div>
          <span class="ws-tabs-count">${n.tabs.length} tabs</span>
        </div>
        <div class="ws-actions">
          <button class="om-btn primary btn-restore-ws" style="flex: 1; height: 28px; font-size: 11px;">🚀 Restore Workspace</button>
          <button class="om-btn btn-del-ws" style="height: 28px; font-size: 11px; color: #ef4444;">✕</button>
        </div>
      </div>
    `).join(""),t.querySelectorAll(".btn-restore-ws").forEach(n=>{n.addEventListener("click",i=>{const r=i.target.closest(".workspace-card"),c=r==null?void 0:r.getAttribute("data-ws-id"),u=e.find(p=>p.id===c);u&&(chrome.runtime.sendMessage({action:"RESTORE_WORKSPACE",tabs:u.tabs}),this.showToast(`Restoring ${u.tabs.length} tabs!`))})}),t.querySelectorAll(".btn-del-ws").forEach(n=>{n.addEventListener("click",async i=>{const r=i.target.closest(".workspace-card"),c=r==null?void 0:r.getAttribute("data-ws-id");c&&(await G(c),this.refreshWorkspaces(),this.showToast("Workspace deleted."))})})}async refreshNotes(){if(!this.shadow)return;const t=this.shadow.getElementById("saved-notes-history");if(!t)return;const e=await C();if(e.length===0){t.innerHTML="";return}t.innerHTML=e.slice(0,5).map(n=>`
      <div style="background: #1e293b; border: 1px solid rgba(255,255,255,0.08); border-radius: 6px; padding: 8px 10px; font-size: 12px;">
        <strong style="color: #f8fafc; display: block;">${n.meetingTitle}</strong>
        <span style="color: #64748b; font-size: 10px;">${n.date} • ${n.actionItems.length} action items</span>
      </div>
    `).join("")}initShortcuts(){const t=e=>{const n=e.code==="KeyC"||e.key.toLowerCase()==="c",i=e.code==="KeyO"||e.key.toLowerCase()==="o",r=e.altKey&&e.shiftKey&&(n||i),c=e.ctrlKey&&e.shiftKey&&n;(r||c)&&(e.preventDefault(),e.stopPropagation(),this.toggleSidebar())};window.addEventListener("keydown",t,{capture:!0}),document.addEventListener("keydown",t,{capture:!0})}}function Y(o){if(!/outlook\.(office|live|office365)\.com/i.test(window.location.hostname))return;new MutationObserver(()=>{q()}).observe(document.body,{childList:!0,subtree:!0}),q()}function q(o){document.querySelectorAll('[role="textbox"][contenteditable="true"], .elementToProof').forEach(e=>{var i;if(e.getAttribute("data-officemate-injected")==="true")return;e.setAttribute("data-officemate-injected","true");const n=document.createElement("div");n.className="officemate-outlook-quickbar",n.style.cssText=`
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      background: #1e293b;
      border: 1px solid rgba(99, 102, 241, 0.4);
      border-radius: 6px;
      margin-bottom: 6px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 11.5px;
      color: #f8fafc;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
    `,n.innerHTML=`
      <span style="font-weight: 700; color: #818cf8; display: flex; align-items: center; gap: 4px;">
        ⚡ OfficeMate AI:
      </span>
      <button class="om-quick-tone" data-tone="polite_pushback" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: #ffffff; padding: 3px 8px; border-radius: 4px; cursor: pointer; font-size: 11px;">Polite Pushback</button>
      <button class="om-quick-tone" data-tone="executive_status" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: #ffffff; padding: 3px 8px; border-radius: 4px; cursor: pointer; font-size: 11px;">Status Update</button>
      <button class="om-quick-tone" data-tone="formal_confirmation" style="background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: #ffffff; padding: 3px 8px; border-radius: 4px; cursor: pointer; font-size: 11px;">Confirmation</button>
    `,(i=e.parentElement)==null||i.insertBefore(n,e),n.querySelectorAll(".om-quick-tone").forEach(r=>{r.addEventListener("click",async c=>{var l,f;c.preventDefault();const u=r.getAttribute("data-tone"),{allowed:p}=await D();if(!p){let s=n.querySelector(".om-warn");s||(s=document.createElement("div"),s.className="om-warn",s.style.cssText="color: #f87171; font-size: 11px; margin-top: 4px; font-weight: 600; width: 100%;",n.appendChild(s)),s.innerHTML='⚠️ Daily free limit reached! <a href="https://sajusun.gumroad.com/l/officemate-pro" target="_blank" style="color: #fbbf24; font-weight: 700; text-decoration: underline; margin-left: 4px;">Upgrade to Pro on Gumroad ↗</a>';return}const h=await y(),a=((f=(l=document.querySelector('[role="main"]'))==null?void 0:l.textContent)==null?void 0:f.substring(0,500))||"",d=await g(u,{incomingText:a},h);await O(),e.focus(),document.execCommand("insertText",!1,d)})})})}const Q=`:host {\r
  all: initial;\r
  position: fixed;\r
  z-index: 2147483646;\r
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;\r
  color: #f8fafc;\r
  box-sizing: border-box;\r
}\r
\r
*, *::before, *::after {\r
  box-sizing: border-box;\r
  scrollbar-width: thin;\r
  scrollbar-color: rgba(255, 255, 255, 0.18) transparent;\r
}\r
\r
/* Ultra-Thin Modern Scrollbars */\r
::-webkit-scrollbar {\r
  width: 5px;\r
  height: 5px;\r
}\r
\r
::-webkit-scrollbar-track {\r
  background: transparent;\r
}\r
\r
::-webkit-scrollbar-thumb {\r
  background: rgba(255, 255, 255, 0.18);\r
  border-radius: 9999px;\r
}\r
\r
::-webkit-scrollbar-thumb:hover {\r
  background: #38bdf8;\r
}\r
\r
/* Floating Launch Pill */\r
.officemate-pill {\r
  position: fixed;\r
  bottom: 24px;\r
  right: 24px;\r
  display: flex;\r
  align-items: center;\r
  gap: 8px;\r
  background: rgba(15, 23, 42, 0.92);\r
  backdrop-filter: blur(16px);\r
  -webkit-backdrop-filter: blur(16px);\r
  border: 1px solid rgba(255, 255, 255, 0.15);\r
  box-shadow: 0 12px 36px rgba(0, 0, 0, 0.45);\r
  border-radius: 9999px;\r
  padding: 8px 14px;\r
  cursor: pointer;\r
  user-select: none;\r
  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);\r
}\r
\r
.officemate-pill:hover {\r
  transform: translateY(-2px);\r
  border-color: rgba(99, 102, 241, 0.4);\r
  box-shadow: 0 16px 44px rgba(79, 70, 229, 0.3);\r
}\r
\r
.pill-logo {\r
  width: 24px;\r
  height: 24px;\r
  border-radius: 6px;\r
  background: linear-gradient(135deg, #0078d4, #4f46e5);\r
  color: #ffffff;\r
  font-weight: 800;\r
  font-size: 11px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
}\r
\r
.pill-text {\r
  font-size: 13px;\r
  font-weight: 700;\r
  background: linear-gradient(90deg, #38bdf8, #818cf8);\r
  -webkit-background-clip: text;\r
  -webkit-text-fill-color: transparent;\r
}\r
\r
.pill-badge {\r
  font-size: 10px;\r
  font-weight: 700;\r
  padding: 2px 6px;\r
  border-radius: 9999px;\r
  background: rgba(99, 102, 241, 0.2);\r
  color: #a5b4fc;\r
}\r
\r
/* Collapsible Right Sidebar */\r
.officemate-sidebar {\r
  position: fixed;\r
  top: 0;\r
  right: -420px;\r
  width: 400px;\r
  height: 100vh;\r
  background: #0f172a;\r
  border-left: 1px solid rgba(255, 255, 255, 0.12);\r
  box-shadow: -12px 0 40px rgba(0, 0, 0, 0.6);\r
  display: flex;\r
  flex-direction: column;\r
  transition: right 0.3s cubic-bezier(0.16, 1, 0.3, 1);\r
  z-index: 2147483647;\r
}\r
\r
.officemate-sidebar.open {\r
  right: 0;\r
}\r
\r
/* Sidebar Header */\r
.sidebar-header {\r
  padding: 16px 20px;\r
  background: #1e293b;\r
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\r
  display: flex;\r
  align-items: center;\r
  justify-content: space-between;\r
}\r
\r
.sidebar-title-group {\r
  display: flex;\r
  align-items: center;\r
  gap: 8px;\r
}\r
\r
.sidebar-title {\r
  font-size: 15px;\r
  font-weight: 700;\r
  color: #ffffff;\r
}\r
\r
.close-btn {\r
  background: none;\r
  border: none;\r
  color: #94a3b8;\r
  font-size: 18px;\r
  cursor: pointer;\r
  padding: 4px;\r
}\r
\r
.close-btn:hover {\r
  color: #ffffff;\r
}\r
\r
/* Tabs */\r
.sidebar-tabs {\r
  display: flex;\r
  background: #1e293b;\r
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\r
}\r
\r
.tab-btn {\r
  flex: 1;\r
  padding: 10px 0;\r
  background: none;\r
  border: none;\r
  border-bottom: 2px solid transparent;\r
  color: #94a3b8;\r
  font-size: 12px;\r
  font-weight: 600;\r
  cursor: pointer;\r
  transition: all 0.15s ease;\r
}\r
\r
.tab-btn:hover {\r
  color: #ffffff;\r
}\r
\r
.tab-btn.active {\r
  color: #38bdf8;\r
  border-bottom-color: #38bdf8;\r
}\r
\r
/* Body / Panels */\r
.sidebar-body {\r
  flex: 1;\r
  overflow-y: auto;\r
  padding: 18px 20px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 16px;\r
}\r
\r
.panel {\r
  display: none;\r
  flex-direction: column;\r
  gap: 14px;\r
}\r
\r
.panel.active {\r
  display: flex;\r
}\r
\r
/* Form Controls & Buttons */\r
.section-title {\r
  font-size: 11px;\r
  font-weight: 700;\r
  text-transform: uppercase;\r
  color: #94a3b8;\r
  letter-spacing: 0.5px;\r
}\r
\r
.tone-grid {\r
  display: grid;\r
  grid-template-columns: 1fr 1fr;\r
  gap: 8px;\r
}\r
\r
.tone-card {\r
  padding: 10px 12px;\r
  background: #1e293b;\r
  border: 1px solid rgba(255, 255, 255, 0.08);\r
  border-radius: 8px;\r
  color: #cbd5e1;\r
  font-size: 12px;\r
  font-weight: 600;\r
  text-align: left;\r
  cursor: pointer;\r
  transition: all 0.15s ease;\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
}\r
\r
.tone-card:hover {\r
  background: rgba(99, 102, 241, 0.15);\r
  border-color: rgba(99, 102, 241, 0.4);\r
  color: #ffffff;\r
}\r
\r
.tone-card.active {\r
  background: linear-gradient(135deg, #0078d4, #4f46e5);\r
  border-color: #818cf8;\r
  color: #ffffff;\r
}\r
\r
.om-textarea {\r
  width: 100%;\r
  background: #1e293b;\r
  border: 1px solid rgba(255, 255, 255, 0.1);\r
  border-radius: 8px;\r
  padding: 10px 12px;\r
  color: #f8fafc;\r
  font-size: 12.5px;\r
  font-family: inherit;\r
  line-height: 1.5;\r
  resize: vertical;\r
}\r
\r
.om-textarea:focus {\r
  outline: none;\r
  border-color: #38bdf8;\r
}\r
\r
.om-btn {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 6px;\r
  padding: 8px 14px;\r
  border-radius: 8px;\r
  background: #1e293b;\r
  border: 1px solid rgba(255, 255, 255, 0.1);\r
  color: #ffffff;\r
  font-size: 12px;\r
  font-weight: 600;\r
  cursor: pointer;\r
  transition: all 0.15s ease;\r
}\r
\r
.om-btn:hover {\r
  background: rgba(255, 255, 255, 0.08);\r
  border-color: rgba(255, 255, 255, 0.2);\r
}\r
\r
.om-btn.primary {\r
  background: linear-gradient(135deg, #0078d4, #4f46e5);\r
  border-color: #818cf8;\r
  color: #ffffff;\r
}\r
\r
.om-btn.primary:hover {\r
  box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4);\r
}\r
\r
/* Draft Preview Box */\r
.draft-preview-box {\r
  background: #1e293b;\r
  border: 1px solid rgba(255, 255, 255, 0.08);\r
  border-radius: 8px;\r
  padding: 12px 14px;\r
  font-size: 12.5px;\r
  line-height: 1.6;\r
  white-space: pre-wrap;\r
  color: #e2e8f0;\r
  max-height: 240px;\r
  overflow-y: auto;\r
}\r
\r
/* Workspace Stash Cards */\r
.workspace-card {\r
  background: #1e293b;\r
  border: 1px solid rgba(255, 255, 255, 0.08);\r
  border-radius: 8px;\r
  padding: 12px 14px;\r
  display: flex;\r
  flex-direction: column;\r
  gap: 8px;\r
}\r
\r
.workspace-card:hover {\r
  border-color: rgba(99, 102, 241, 0.35);\r
}\r
\r
.ws-header {\r
  display: flex;\r
  align-items: center;\r
  justify-content: space-between;\r
}\r
\r
.ws-title {\r
  font-size: 13.5px;\r
  font-weight: 700;\r
  color: #ffffff;\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
}\r
\r
.ws-color-dot {\r
  width: 8px;\r
  height: 8px;\r
  border-radius: 50%;\r
}\r
\r
.ws-tabs-count {\r
  font-size: 11px;\r
  color: #94a3b8;\r
}\r
\r
.ws-actions {\r
  display: flex;\r
  gap: 6px;\r
}\r
\r
/* Outlook In-Page Toolbar (Floating above compose box) */\r
.outlook-inpage-toolbar {\r
  display: flex;\r
  align-items: center;\r
  gap: 6px;\r
  background: #1e293b;\r
  border: 1px solid rgba(99, 102, 241, 0.4);\r
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);\r
  border-radius: 8px;\r
  padding: 6px 10px;\r
  margin: 6px 0;\r
  font-size: 12px;\r
}\r
\r
/* Toast */\r
.om-toast {\r
  position: fixed;\r
  bottom: 24px;\r
  left: 50%;\r
  transform: translateX(-50%);\r
  background: #059669;\r
  color: #ffffff;\r
  padding: 8px 18px;\r
  border-radius: 9999px;\r
  font-size: 12.5px;\r
  font-weight: 600;\r
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);\r
  z-index: 2147483647;\r
  pointer-events: none;\r
}\r
`;let w=null;function N(){if(!w)try{w=new V(Q),w.init(),Y(),console.log("⚡ OfficeMate for Edge initialized on page.")}catch(o){console.error("Failed to initialize OfficeMate",o)}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",N):N(),chrome.runtime.onMessage.addListener((o,t,e)=>(o.action==="TOGGLE_SIDEBAR"&&(w==null||w.toggleSidebar(),e({success:!0})),!0))})();
