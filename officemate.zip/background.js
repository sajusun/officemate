function P(t) {
  function r(a, d) {
    return a >>> d | a << 32 - d;
  }
  const o = Math.pow, c = o(2, 32), i = "length";
  let e, n, y = "";
  const u = [], I = t[i] * 8, s = [], b = [];
  let h = 0;
  const T = {};
  for (let a = 2; h < 64; a++)
    if (!T[a]) {
      for (e = 0; e < 313; e += a)
        T[e] = !0;
      s[h] = o(a, 0.5) * c | 0, b[h++] = o(a, 1 / 3) * c | 0;
    }
  for (t += ""; t[i] % 64 - 56; ) t += "\0";
  for (e = 0; e < t[i]; e++)
    n = t.charCodeAt(e), u[e >> 2] |= n << (3 - e) % 4 * 8;
  for (u[u[i]] = I / c | 0, u[u[i]] = I, n = 0; n < u[i]; ) {
    const a = u.slice(n, n += 16), d = s.slice(0, 8);
    for (e = 0; e < 64; e++) {
      const g = a[e - 15], p = a[e - 2], f = s[0], l = s[4], A = s[7] + (r(l, 6) ^ r(l, 11) ^ r(l, 25)) + (l & s[5] ^ ~l & s[6]) + b[e] + (a[e] = e < 16 ? a[e] : a[e - 16] + (r(g, 7) ^ r(g, 18) ^ g >>> 3) + a[e - 7] + (r(p, 17) ^ r(p, 19) ^ p >>> 10) | 0), L = (r(f, 2) ^ r(f, 13) ^ r(f, 22)) + (f & s[1] ^ f & s[2] ^ s[1] & s[2]);
      s[7] = s[6], s[6] = s[5], s[5] = s[4], s[4] = s[3] + A | 0, s[3] = s[2], s[2] = s[1], s[1] = s[0], s[0] = A + L | 0;
    }
    for (e = 0; e < 8; e++)
      s[e] = s[e] + d[e] | 0;
  }
  for (e = 0; e < 8; e++)
    for (let a = 3; a >= 0; a--) {
      const d = s[e] >> a * 8 & 255;
      y += (d < 16 ? "0" : "") + d.toString(16);
    }
  return y;
}
const v = "OM_#2pQ9!", M = "@zXc4$bN";
function C(t, r) {
  const o = t.trim().toUpperCase();
  return P(`${v}:${o}:${M}:${r}`);
}
function k(t, r) {
  if (!t.isPro)
    return { isValid: !0, sanitized: t };
  if (!t.proLicenseKey || !t.proAuthSig || !r)
    return {
      isValid: !1,
      sanitized: {
        ...t,
        isPro: !1,
        proLicenseKey: "",
        proAuthSig: void 0
      }
    };
  const o = C(t.proLicenseKey, r);
  return t.proAuthSig !== o ? {
    isValid: !1,
    sanitized: {
      ...t,
      isPro: !1,
      proLicenseKey: "",
      proAuthSig: void 0
    }
  } : { isValid: !0, sanitized: t };
}
const m = "officemate_settings", w = "officemate_workspaces", O = 1;
function W() {
  return (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
}
const G = {
  isPro: !1,
  aiProvider: "offline",
  userFullName: "Alex Mercer",
  userJobTitle: "Senior Product Lead",
  companyName: "Enterprise Solutions",
  emailSignature: `Best regards,
Alex Mercer
Senior Product Lead`,
  freeDraftsUsedToday: 0,
  lastDraftDate: W()
}, S = "officemate_device_id";
async function K() {
  return new Promise((t) => {
    chrome.storage.local.get([S], (r) => {
      let o = r[S];
      if (!o) {
        const c = [
          typeof navigator < "u" ? navigator.userAgent : "",
          typeof navigator < "u" ? navigator.language : "",
          typeof screen < "u" ? `${screen.width}x${screen.height}` : "",
          Date.now().toString(),
          Math.random().toString(36).substring(2)
        ].join("|");
        o = "om-dev-" + P(c).substring(0, 16), chrome.storage.local.set({ [S]: o });
      }
      t(o);
    });
  });
}
async function x() {
  const t = await K();
  return new Promise((r) => {
    chrome.storage.local.get([m], (o) => {
      let c = o[m] || { ...G };
      const { isValid: i, sanitized: e } = k(c, t);
      i || chrome.storage.local.set({ [m]: e });
      const n = W();
      e.lastDraftDate !== n && (e.lastDraftDate = n, e.freeDraftsUsedToday = 0, chrome.storage.local.set({ [m]: e })), r(e);
    });
  });
}
async function R() {
  return new Promise((t) => {
    chrome.storage.local.get([w], (r) => {
      t(r[w] || []);
    });
  });
}
async function z(t) {
  const r = await x(), o = await R();
  if (!o.some((e) => e.id === t.id) && !r.isPro && o.length >= O)
    return {
      success: !1,
      message: "Free tier is limited to 1 Project Workspace. Upgrade to Pro for unlimited workspaces!"
    };
  const i = o.findIndex((e) => e.id === t.id);
  return i >= 0 ? o[i] = t : o.unshift(t), await new Promise((e) => {
    chrome.storage.local.set({ [w]: o }, () => e());
  }), { success: !0, message: "Workspace saved successfully!" };
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "officemate_parent",
    title: "OfficeMate Copilot",
    contexts: ["page", "selection"]
  }), chrome.contextMenus.create({
    id: "officemate_stash_tabs",
    parentId: "officemate_parent",
    title: "🗂️ Stash All Project Tabs",
    contexts: ["page"]
  }), chrome.contextMenus.create({
    id: "officemate_grab_actions",
    parentId: "officemate_parent",
    title: "📌 Grab Action Items from Selection",
    contexts: ["selection"]
  }), chrome.contextMenus.create({
    id: "officemate_open_sidebar",
    parentId: "officemate_parent",
    title: "⚡ Open OfficeMate Sidebar",
    contexts: ["page"]
  }), console.log("⚡ OfficeMate for Edge Background Worker installed.");
});
function D(t) {
  chrome.tabs.sendMessage(t, { action: "TOGGLE_SIDEBAR" }, () => {
    chrome.runtime.lastError && chrome.scripting.executeScript(
      {
        target: { tabId: t },
        files: ["content.js"]
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(t, { action: "TOGGLE_SIDEBAR" });
        }, 100);
      }
    );
  });
}
chrome.contextMenus.onClicked.addListener(async (t, r) => {
  !(r != null && r.id) || !r.url || r.url.startsWith("edge://") || r.url.startsWith("chrome://") || (t.menuItemId === "officemate_open_sidebar" ? D(r.id) : t.menuItemId === "officemate_stash_tabs" && await _("Quick Stash"));
});
chrome.commands.onCommand.addListener(async (t) => {
  const [r] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  !(r != null && r.id) || !r.url || r.url.startsWith("edge://") || r.url.startsWith("chrome://") || (t === "toggle_officemate_sidebar" ? D(r.id) : t === "quick_stash_workspace" && await _("Stashed Workspace"));
});
async function _(t) {
  const r = await chrome.tabs.query({ currentWindow: !0 }), o = [], c = [];
  for (const n of r)
    !n.url || n.url.startsWith("edge://") || n.url.startsWith("chrome://") || (o.push({
      title: n.title || "Tab",
      url: n.url,
      favIconUrl: n.favIconUrl
    }), n.id && c.push(n.id));
  if (o.length === 0)
    return { success: !1, count: 0, message: "No standard web tabs to stash in this window." };
  const i = {
    id: "ws_" + Date.now(),
    name: t,
    color: "#0078d4",
    tabs: o,
    createdAt: Date.now(),
    updatedAt: Date.now()
  }, e = await z(i);
  return e.success ? (await chrome.tabs.create({}), c.length > 0 && await chrome.tabs.remove(c), { success: !0, count: o.length }) : { success: !1, count: 0, message: e.message };
}
chrome.runtime.onMessage.addListener((t, r, o) => t.action === "STASH_TABS" ? ((async () => {
  const c = await _(t.name || "Project Workspace");
  o(c);
})(), !0) : (t.action === "RESTORE_WORKSPACE" && (async () => {
  const c = t.tabs || [], i = [];
  for (const e of c) {
    const n = await chrome.tabs.create({ url: e.url, active: !1 });
    n.id && i.push(n.id);
  }
  if (chrome.tabGroups && i.length > 0)
    try {
      const e = await chrome.tabs.group({ tabIds: i });
      await chrome.tabGroups.update(e, {
        title: t.name || "Restored Workspace",
        color: "blue"
      });
    } catch {
    }
  o({ success: !0 });
})(), !0));
var E;
typeof chrome < "u" && ((E = chrome.storage) != null && E.onChanged) && chrome.storage.onChanged.addListener(async (t, r) => {
  r === "local" && t.officemate_settings && await x();
});
