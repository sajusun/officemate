(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))c(s);new MutationObserver(s=>{for(const t of s)if(t.type==="childList")for(const l of t.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&c(l)}).observe(document,{childList:!0,subtree:!0});function n(s){const t={};return s.integrity&&(t.integrity=s.integrity),s.referrerPolicy&&(t.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?t.credentials="include":s.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function c(s){if(s.ep)return;s.ep=!0;const t=n(s);fetch(s.href,t)}})();function K(e){function o(u,v){return u>>>v|u<<32-v}const n=Math.pow,c=n(2,32),s="length";let t,l,y="";const d=[],g=e[s]*8,i=[],p=[];let m=0;const w={};for(let u=2;m<64;u++)if(!w[u]){for(t=0;t<313;t+=u)w[t]=!0;i[m]=n(u,.5)*c|0,p[m++]=n(u,1/3)*c|0}for(e+="";e[s]%64-56;)e+="\0";for(t=0;t<e[s];t++)l=e.charCodeAt(t),d[t>>2]|=l<<(3-t)%4*8;for(d[d[s]]=g/c|0,d[d[s]]=g,l=0;l<d[s];){const u=d.slice(l,l+=16),v=i.slice(0,8);for(t=0;t<64;t++){const I=u[t-15],S=u[t-2],b=i[0],E=i[4],B=i[7]+(o(E,6)^o(E,11)^o(E,25))+(E&i[5]^~E&i[6])+p[t]+(u[t]=t<16?u[t]:u[t-16]+(o(I,7)^o(I,18)^I>>>3)+u[t-7]+(o(S,17)^o(S,19)^S>>>10)|0),$=(o(b,2)^o(b,13)^o(b,22))+(b&i[1]^b&i[2]^i[1]&i[2]);i[7]=i[6],i[6]=i[5],i[5]=i[4],i[4]=i[3]+B|0,i[3]=i[2],i[2]=i[1],i[1]=i[0],i[0]=B+$|0}for(t=0;t<8;t++)i[t]=i[t]+v[t]|0}for(t=0;t<8;t++)for(let u=3;u>=0;u--){const v=i[t]>>u*8&255;y+=(v<16?"0":"")+v.toString(16)}return y}const Z="OM_#2pQ9!",ee="@zXc4$bN",te="52c335dad94f848fd4be8523dc92aad3e0ae2cf532d6b77f456cd259f767f9ab";function ne(e){return!e||typeof e!="string"?!1:K(e.trim().toUpperCase())===te}function M(e,o){const n=e.trim().toUpperCase();return K(`${Z}:${n}:${ee}:${o}`)}function oe(e,o){if(!e.isPro)return{isValid:!0,sanitized:e};if(!e.proLicenseKey||!e.proAuthSig||!o)return{isValid:!1,sanitized:{...e,isPro:!1,proLicenseKey:"",proAuthSig:void 0}};const n=M(e.proLicenseKey,o);return e.proAuthSig!==n?{isValid:!1,sanitized:{...e,isPro:!1,proLicenseKey:"",proAuthSig:void 0}}:{isValid:!0,sanitized:e}}const O=3,ae="https://sajusun.github.io/extensions/officemate/",j="ujrPYYMB6DKRyi6Exc7rWw==",se="officemate-pro",C="officemate_settings",R="officemate_workspaces",H=3;function q(){return new Date().toISOString().split("T")[0]}const ie={isPro:!1,aiProvider:"offline",userFullName:"Alex Mercer",userJobTitle:"Senior Product Lead",companyName:"Enterprise Solutions",emailSignature:`Best regards,
Alex Mercer
Senior Product Lead`,freeDraftsUsedToday:0,lastDraftDate:q()},D="officemate_device_id";async function V(){return new Promise(e=>{chrome.storage.local.get([D],o=>{let n=o[D];if(!n){const c=[typeof navigator<"u"?navigator.userAgent:"",typeof navigator<"u"?navigator.language:"",typeof screen<"u"?`${screen.width}x${screen.height}`:"",Date.now().toString(),Math.random().toString(36).substring(2)].join("|");n="om-dev-"+K(c).substring(0,16),chrome.storage.local.set({[D]:n})}e(n)})})}async function P(){const e=await V();return new Promise(o=>{chrome.storage.local.get([C],n=>{let c=n[C]||{...ie};const{isValid:s,sanitized:t}=oe(c,e);s||chrome.storage.local.set({[C]:t});const l=q();t.lastDraftDate!==l&&(t.lastDraftDate=l,t.freeDraftsUsedToday=0,chrome.storage.local.set({[C]:t})),o(t)})})}async function k(e){const n={...await P(),...e};return new Promise(c=>{chrome.storage.local.set({[C]:n},()=>c(n))})}async function re(){const e=await P();if(e.isPro)return{allowed:!0,remaining:9999,isPro:!0};const o=Math.max(0,H-e.freeDraftsUsedToday);return{allowed:o>0,remaining:o,isPro:!1}}async function ce(){const e=await P();return e.isPro?9999:(e.freeDraftsUsedToday+=1,await k(e),Math.max(0,H-e.freeDraftsUsedToday))}async function J(){return new Promise(e=>{chrome.storage.local.get([R],o=>{e(o[R]||[])})})}async function le(e){const n=(await J()).filter(c=>c.id!==e);return new Promise(c=>{chrome.storage.local.set({[R]:n},()=>c())})}async function de(e,o=se){var t,l;const n=e.trim();if(!n)return{success:!1,message:"License key cannot be empty."};const c=await P();if(c.isPro&&c.proLicenseKey===n)return{success:!0,message:"This device is already activated with OfficeMate Pro!"};const s=await V();if(ne(n)){const y=M(n,s);return await k({isPro:!0,proLicenseKey:n.toUpperCase(),proAuthSig:y,proActivatedAt:Date.now()}),{success:!0,message:"🎉 OfficeMate Pro Activated! Unlimited AI drafts & workspaces unlocked."}}if(n.length<8)return{success:!1,message:"Invalid license key format. Please check the key from your Gumroad receipt."};try{const d=await(await fetch("https://api.gumroad.com/v2/licenses/verify",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({product_id:j,product_permalink:o,license_key:n,increment_uses_count:"false"})})).json();if(!d||d.success!==!0)return{success:!1,message:`❌ Verification failed: ${(d==null?void 0:d.message)||"The entered license key could not be verified on Gumroad."}`};if((t=d.purchase)!=null&&t.refunded||(l=d.purchase)!=null&&l.chargebacked)return{success:!1,message:"❌ Verification failed: This license key has been refunded or disputed."};const g=typeof d.uses=="number"?d.uses:0;if(g>=O)return{success:!1,message:`❌ Activation limit reached (${g}/${O} devices). If you upgraded or changed your device, please visit ${ae} for assistance.`};const p=await(await fetch("https://api.gumroad.com/v2/licenses/verify",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({product_id:j,product_permalink:o,license_key:n,increment_uses_count:"true"})})).json();if(p&&p.success===!0){const m=typeof p.uses=="number"?p.uses:g+1,w=M(n,s);return await k({isPro:!0,proLicenseKey:n,proAuthSig:w,proActivatedAt:Date.now()}),{success:!0,message:`🎉 OfficeMate Pro Lifetime License Activated! (Device ${m} of ${O})`}}else return{success:!1,message:`❌ Activation failed: ${(p==null?void 0:p.message)||"Could not complete device registration."}`}}catch(y){return{success:!1,message:`Could not connect to Gumroad license server (${(y==null?void 0:y.message)||"Check your connection"}).`}}}function L(e,o,n){const c=o.recipientName||"Team",s=n.userFullName||"Best",t=n.userJobTitle||"",l=`

Best regards,
${s}${t?`
${t}`:""}`;switch(e){case"polite_pushback":return`Hi ${c},

Thank you for reaching out and sharing the updated requirements.

While I understand the urgency of this deliverable, our team is currently committed to existing high-priority milestones. Taking on this additional scope at this time would compromise the quality and delivery schedule of our core commitments.

I recommend we either:
1. Schedule this for our upcoming sprint/cycle starting next week, or
2. Re-prioritize our current backlog so we can allocate dedicated focus.

Let me know which option aligns best with your roadmap.${l}`;case"executive_status":return`Hi ${c},

Please find below our weekly executive status update:

• Completed Deliverables:
  - Finalized system review and stakeholder alignment.
  - Resolved all critical path items for the current phase.

• Currently In Progress:
  - Quality assurance testing and documentation wrap-up.
  - Coordinating with cross-functional partners for deployment.

• Blockers & Risks:
  - None at this time. All milestones remain on track.

• Next Steps:
  - Review meeting scheduled for Thursday to finalize launch readiness.

Please let me know if you require any additional metrics or details.${l}`;case"formal_confirmation":return`Hi ${c},

Thank you for the productive discussion. 

I am writing to formally confirm our alignment on the agreed action items and timeline:
• Scope: ${o.keyPoints||"As discussed in our meeting"}
• Target Delivery Date: ${o.deadline||"End of week"}

Our team has initiated the next steps and we will share progress checkpoints accordingly. If there are any revisions needed, please feel free to flag them by EOD tomorrow.${l}`;case"friendly_followup":return`Hi ${c},

Hope you are having a productive week!

I wanted to quickly circle back regarding our previous discussion on ${o.keyPoints||"the project proposal"}. 

When you have a moment, could you please share a quick update or let me know if you need any additional inputs from my end to move forward?

Looking forward to hearing from you.${l}`;case"meeting_reschedule":return`Hi ${c},

I hope you are doing well.

Due to an unavoidable scheduling conflict with an executive client briefing, I will need to request rescheduling our meeting scheduled for today.

Would any of the following alternate time slots work on your calendar?
• Tomorrow at 11:00 AM EST
• Thursday at 2:30 PM EST
• Friday at 10:00 AM EST

My sincere apologies for any inconvenience this may cause, and thank you for your flexibility.${l}`;default:return`Hi ${c},

Thank you for the update. Everything looks aligned from our perspective.

Please let me know if you need any further assistance.${l}`}}async function ue(e,o,n){var s,t,l,y,d,g,i,p;if(n.aiProvider==="offline"||!n.aiApiKey)return L(e,o,n);const c=`You are OfficeMate, an expert Microsoft 365 executive email assistant.
Write a professional corporate email response.
Tone: ${e.replace("_"," ").toUpperCase()}
Sender: ${n.userFullName} (${n.userJobTitle} at ${n.companyName})
Recipient: ${o.recipientName||"Colleague / Client"}
Context / Incoming Email:
"${o.incomingText||"Follow up on project status"}"
Key Points to Include:
"${o.keyPoints||"Confirm timeline and align on next steps"}"

Guidelines:
- Clear, concise, executive tone.
- Professional corporate etiquette.
- Include a polite sign-off with the sender's name and title.`;try{if(n.aiProvider==="openai"){const m=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n.aiApiKey}`},body:JSON.stringify({model:n.aiModel||"gpt-4o-mini",messages:[{role:"user",content:c}],temperature:.3})});if(!m.ok)throw new Error(m.statusText);return((l=(t=(s=(await m.json()).choices)==null?void 0:s[0])==null?void 0:t.message)==null?void 0:l.content)||L(e,o,n)}if(n.aiProvider==="gemini"){const m=n.aiModel||"gemini-1.5-flash",w=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${n.aiApiKey}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:c}]}]})});if(!w.ok)throw new Error(w.statusText);return((p=(i=(g=(d=(y=(await w.json()).candidates)==null?void 0:y[0])==null?void 0:d.content)==null?void 0:g.parts)==null?void 0:i[0])==null?void 0:p.text)||L(e,o,n)}}catch(m){return console.warn("AI API call failed, falling back to corporate template",m),L(e,o,n)}return L(e,o,n)}document.addEventListener("DOMContentLoaded",async()=>{let e=await P();const o=document.getElementById("plan-badge"),n=document.getElementById("stash-name-input"),c=document.getElementById("btn-popup-stash"),s=document.getElementById("popup-workspaces-list"),t=document.getElementById("workspaces-count"),l=document.getElementById("draft-tone-select"),y=document.getElementById("draft-notes-input"),d=document.getElementById("btn-popup-generate"),g=document.getElementById("draft-copied-msg"),i=document.getElementById("setting-name"),p=document.getElementById("setting-title"),m=document.getElementById("setting-ai-provider"),w=document.getElementById("group-api-key"),u=document.getElementById("setting-api-key"),v=document.getElementById("setting-license-key"),I=document.getElementById("btn-activate-pro"),S=document.getElementById("btn-open-inpage-sidebar"),b=document.getElementById("banner-buy-pro"),E=document.getElementById("custom-modal-backdrop"),B=document.getElementById("modal-icon"),$=document.getElementById("modal-title"),Y=document.getElementById("modal-message"),N=document.getElementById("modal-btn-close"),U=document.getElementById("modal-btn-ok"),Q=document.getElementById("modal-btn-pro"),x=document.getElementById("popup-toast");function T(a){B.textContent=a.icon||"ℹ️",$.textContent=a.title,Y.textContent=a.message,Q.style.display=a.showProBtn?"inline-flex":"none",E.style.display="flex";const r=()=>{E.style.display="none",N.removeEventListener("click",r),U.removeEventListener("click",r),a.onClose&&a.onClose()};N.addEventListener("click",r),U.addEventListener("click",r)}function G(a){x.textContent=a,x.style.display="block",setTimeout(()=>{x.style.display="none"},2500)}function W(){e.isPro?(o.className="badge-pro",o.textContent="👑 PRO",b&&(b.style.display="none")):(o.className="badge-free",o.textContent="FREE",b&&(b.style.display="flex"))}W();const F=document.querySelectorAll(".tab-btn"),X=document.querySelectorAll(".tab-panel");F.forEach(a=>{a.addEventListener("click",()=>{var f;F.forEach(h=>h.classList.remove("active")),X.forEach(h=>h.classList.remove("active")),a.classList.add("active");const r=a.getAttribute("data-tab");(f=document.getElementById(`panel-${r}`))==null||f.classList.add("active")})}),c.addEventListener("click",()=>{const a=n.value.trim()||`Workspace ${new Date().toLocaleDateString()}`;c.disabled=!0,chrome.runtime.sendMessage({action:"STASH_TABS",name:a},r=>{var f;c.disabled=!1,r!=null&&r.success?(n.value="",_(),G(`Stashed ${r.count||"all"} tabs!`)):T({title:"Workspace Notice",icon:"⚠️",message:(r==null?void 0:r.message)||"Could not stash workspace.",showProBtn:!!((f=r==null?void 0:r.message)!=null&&f.includes("Pro"))})})});async function _(){const a=await J();if(t.textContent=String(a.length),a.length===0){s.innerHTML='<div style="text-align: center; color: #64748b; font-size: 12px; padding: 20px 0;">No saved workspaces yet.</div>';return}s.innerHTML=a.map(r=>`
      <div class="workspace-item" data-id="${r.id}">
        <div>
          <strong style="color: #f8fafc; font-size: 12.5px; display: block;">${r.name}</strong>
          <span style="color: #94a3b8; font-size: 11px;">${r.tabs.length} tabs</span>
        </div>
        <div style="display: flex; gap: 4px;">
          <button class="action-btn primary btn-restore" style="padding: 4px 8px; font-size: 11px;">🚀 Open</button>
          <button class="action-btn btn-del" style="padding: 4px 8px; font-size: 11px; color: #ef4444;">✕</button>
        </div>
      </div>
    `).join(""),s.querySelectorAll(".btn-restore").forEach((r,f)=>{r.addEventListener("click",()=>{const h=a[f];chrome.runtime.sendMessage({action:"RESTORE_WORKSPACE",tabs:h.tabs}),window.close()})}),s.querySelectorAll(".btn-del").forEach((r,f)=>{r.addEventListener("click",async()=>{const h=a[f];await le(h.id),_()})})}_(),d.addEventListener("click",async()=>{const{allowed:a}=await re();if(!a){T({title:"Daily Limit Reached",icon:"👑",message:`Daily free email draft limit (3 drafts) reached!

Upgrade to OfficeMate Pro for unlimited drafts, tab workspaces, and priority AI features.`,showProBtn:!0});return}d.disabled=!0,d.textContent="Generating...";const r=l.value,f=y.value.trim(),h=await ue(r,{incomingText:f},e);await ce(),navigator.clipboard.writeText(h),d.disabled=!1,d.textContent="⚡ Generate & Copy Draft",g.style.display="block",setTimeout(()=>{g.style.display="none"},3e3)}),i.value=e.userFullName||"",p.value=`${e.userJobTitle||""}${e.companyName?`, ${e.companyName}`:""}`,m.value=e.aiProvider||"offline",u.value=e.aiApiKey||"";const A=document.getElementById("api-key-link"),z=()=>{const a=m.value==="offline";w.style.display=a?"none":"block",A&&(m.value==="openai"?(A.href="https://platform.openai.com/api-keys",A.textContent="Get OpenAI Key ↗",u.placeholder="sk-..."):m.value==="gemini"&&(A.href="https://aistudio.google.com/app/apikey",A.textContent="Get Gemini Key ↗",u.placeholder="AIzaSy..."))};z(),m.addEventListener("change",async()=>{z(),await k({aiProvider:m.value})}),i.addEventListener("change",async()=>{await k({userFullName:i.value.trim()})}),p.addEventListener("change",async()=>{var f,h;const r=p.value.trim().split(",");await k({userJobTitle:((f=r[0])==null?void 0:f.trim())||"",companyName:((h=r[1])==null?void 0:h.trim())||""})}),u.addEventListener("change",async()=>{await k({aiApiKey:u.value.trim()})}),I.addEventListener("click",async()=>{const a=v.value.trim();if(!a)return;const r=await de(a);r.success?(e=await P(),W(),v.value="",T({title:"Pro Activated",icon:"🎉",message:r.message})):T({title:"Activation Failed",icon:"❌",message:r.message,showProBtn:!0})}),S.addEventListener("click",async()=>{const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(a!=null&&a.id)||!a.url){G("No active tab detected.");return}if(a.url.startsWith("chrome://")||a.url.startsWith("edge://")||a.url.startsWith("about:")||a.url.includes("microsoftedge.microsoft.com")||a.url.includes("chrome.google.com/webstore")){T({title:"Page Not Supported",icon:"⚠️",message:`OfficeMate Copilot cannot run on internal browser pages (edge:// or web store pages).

Please navigate to a regular web page (e.g. Outlook, Teams, Google, or any website) to use the sidebar.`});return}chrome.tabs.sendMessage(a.id,{action:"TOGGLE_SIDEBAR"},f=>{chrome.runtime.lastError||!(f!=null&&f.success)?chrome.scripting.executeScript({target:{tabId:a.id},files:["content.js"]},()=>{setTimeout(()=>{chrome.tabs.sendMessage(a.id,{action:"TOGGLE_SIDEBAR"}),window.close()},120)}):window.close()})})});
