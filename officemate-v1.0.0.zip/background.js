const n = "officemate_settings", i = "officemate_workspaces";
function d() {
  return (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
}
const l = {
  isPro: !1,
  aiProvider: "offline",
  userFullName: "Alex Mercer",
  userJobTitle: "Senior Product Lead",
  companyName: "Enterprise Solutions",
  emailSignature: `Best regards,
Alex Mercer
Senior Product Lead`,
  freeDraftsUsedToday: 0,
  lastDraftDate: d()
};
async function m() {
  return new Promise((e) => {
    chrome.storage.local.get([n], (t) => {
      let s = t[n] || { ...l };
      const a = d();
      s.lastDraftDate !== a && (s.lastDraftDate = a, s.freeDraftsUsedToday = 0, chrome.storage.local.set({ [n]: s })), e(s);
    });
  });
}
async function h() {
  return new Promise((e) => {
    chrome.storage.local.get([i], (t) => {
      e(t[i] || []);
    });
  });
}
async function g(e) {
  const t = await m(), s = await h();
  if (!s.some((r) => r.id === e.id) && !t.isPro && s.length >= 1)
    return {
      success: !1,
      message: "Free tier is limited to 1 Project Workspace. Upgrade to Pro for unlimited workspaces!"
    };
  const c = s.findIndex((r) => r.id === e.id);
  return c >= 0 ? s[c] = e : s.unshift(e), await new Promise((r) => {
    chrome.storage.local.set({ [i]: s }, () => r());
  }), { success: !0, message: "Workspace saved successfully!" };
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "officemate_parent",
    title: "OfficeMate Copilot",
    contexts: ["page", "selection"]
  }), chrome.contextMenus.create({
    id: "officemate_stash_tabs",
    parentId: "officemate_parent",
    title: "🗂️ Stash All Project Tabs",
    contexts: ["page"]
  }), chrome.contextMenus.create({
    id: "officemate_grab_actions",
    parentId: "officemate_parent",
    title: "📌 Grab Action Items from Selection",
    contexts: ["selection"]
  }), chrome.contextMenus.create({
    id: "officemate_open_sidebar",
    parentId: "officemate_parent",
    title: "⚡ Open OfficeMate Sidebar",
    contexts: ["page"]
  }), console.log("⚡ OfficeMate for Edge Background Worker installed.");
});
function f(e) {
  chrome.tabs.sendMessage(e, { action: "TOGGLE_SIDEBAR" }, () => {
    chrome.runtime.lastError && chrome.scripting.executeScript(
      {
        target: { tabId: e },
        files: ["content.js"]
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(e, { action: "TOGGLE_SIDEBAR" });
        }, 100);
      }
    );
  });
}
chrome.contextMenus.onClicked.addListener(async (e, t) => {
  !(t != null && t.id) || !t.url || t.url.startsWith("edge://") || t.url.startsWith("chrome://") || (e.menuItemId === "officemate_open_sidebar" ? f(t.id) : e.menuItemId === "officemate_stash_tabs" && await u("Quick Stash"));
});
chrome.commands.onCommand.addListener(async (e) => {
  const [t] = await chrome.tabs.query({ active: !0, currentWindow: !0 });
  !(t != null && t.id) || !t.url || t.url.startsWith("edge://") || t.url.startsWith("chrome://") || (e === "toggle_officemate_sidebar" ? f(t.id) : e === "quick_stash_workspace" && await u("Stashed Workspace"));
});
async function u(e) {
  const t = await chrome.tabs.query({ currentWindow: !0 }), s = [], a = [];
  for (const o of t)
    !o.url || o.url.startsWith("edge://") || o.url.startsWith("chrome://") || (s.push({
      title: o.title || "Tab",
      url: o.url,
      favIconUrl: o.favIconUrl
    }), o.id && a.push(o.id));
  if (s.length === 0)
    return { success: !1, count: 0, message: "No standard web tabs to stash in this window." };
  const c = {
    id: "ws_" + Date.now(),
    name: e,
    color: "#0078d4",
    tabs: s,
    createdAt: Date.now(),
    updatedAt: Date.now()
  }, r = await g(c);
  return r.success ? (await chrome.tabs.create({}), a.length > 0 && await chrome.tabs.remove(a), { success: !0, count: s.length }) : { success: !1, count: 0, message: r.message };
}
chrome.runtime.onMessage.addListener((e, t, s) => e.action === "STASH_TABS" ? ((async () => {
  const a = await u(e.name || "Project Workspace");
  s(a);
})(), !0) : (e.action === "RESTORE_WORKSPACE" && (async () => {
  const a = e.tabs || [], c = [];
  for (const r of a) {
    const o = await chrome.tabs.create({ url: r.url, active: !1 });
    o.id && c.push(o.id);
  }
  if (chrome.tabGroups && c.length > 0)
    try {
      const r = await chrome.tabs.group({ tabIds: c });
      await chrome.tabGroups.update(r, {
        title: e.name || "Restored Workspace",
        color: "blue"
      });
    } catch {
    }
  s({ success: !0 });
})(), !0));
