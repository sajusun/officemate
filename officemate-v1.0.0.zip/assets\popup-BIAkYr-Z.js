(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const r of i)if(r.type==="childList")for(const c of r.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&s(c)}).observe(document,{childList:!0,subtree:!0});function e(i){const r={};return i.integrity&&(r.integrity=i.integrity),i.referrerPolicy&&(r.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?r.credentials="include":i.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(i){if(i.ep)return;i.ep=!0;const r=e(i);fetch(i.href,r)}})();const A=3,V="https://sajusun.github.io/extensions/officemate/",N="ujrPYYMB6DKRyi6Exc7rWw==",Y="officemate-pro",I="officemate_settings",B="officemate_workspaces",K=3;function F(){return new Date().toISOString().split("T")[0]}const Q={isPro:!1,aiProvider:"offline",userFullName:"Alex Mercer",userJobTitle:"Senior Product Lead",companyName:"Enterprise Solutions",emailSignature:`Best regards,
Alex Mercer
Senior Product Lead`,freeDraftsUsedToday:0,lastDraftDate:F()};async function b(){return new Promise(n=>{chrome.storage.local.get([I],a=>{let e=a[I]||{...Q};const s=F();e.lastDraftDate!==s&&(e.lastDraftDate=s,e.freeDraftsUsedToday=0,chrome.storage.local.set({[I]:e})),n(e)})})}async function g(n){const e={...await b(),...n};return new Promise(s=>{chrome.storage.local.set({[I]:e},()=>s(e))})}async function X(){const n=await b();if(n.isPro)return{allowed:!0,remaining:9999,isPro:!0};const a=Math.max(0,K-n.freeDraftsUsedToday);return{allowed:a>0,remaining:a,isPro:!1}}async function Z(){const n=await b();return n.isPro?9999:(n.freeDraftsUsedToday+=1,await g(n),Math.max(0,K-n.freeDraftsUsedToday))}async function U(){return new Promise(n=>{chrome.storage.local.get([B],a=>{n(a[B]||[])})})}async function ee(n){const e=(await U()).filter(s=>s.id!==n);return new Promise(s=>{chrome.storage.local.set({[B]:e},()=>s())})}async function te(n,a=Y){var i,r;const e=n.trim();if(!e)return{success:!1,message:"License key cannot be empty."};const s=await b();if(s.isPro&&s.proLicenseKey===e)return{success:!0,message:"This device is already activated with OfficeMate Pro!"};if(e.toUpperCase()==="OFFICEMATE-PRO-VIP")return await g({isPro:!0,proLicenseKey:"OFFICEMATE-PRO-VIP"}),{success:!0,message:"🎉 OfficeMate Pro Activated! Unlimited AI drafts & workspaces unlocked."};if(e.length<8)return{success:!1,message:"Invalid license key format. Please check the key from your Gumroad receipt."};try{const d=await(await fetch("https://api.gumroad.com/v2/licenses/verify",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({product_id:N,product_permalink:a,license_key:e,increment_uses_count:"false"})})).json();if(!d||d.success!==!0)return{success:!1,message:`❌ Verification failed: ${(d==null?void 0:d.message)||"The entered license key could not be verified on Gumroad."}`};if((i=d.purchase)!=null&&i.refunded||(r=d.purchase)!=null&&r.chargebacked)return{success:!1,message:"❌ Verification failed: This license key has been refunded or disputed."};const p=typeof d.uses=="number"?d.uses:0;if(p>=A)return{success:!1,message:`❌ Activation limit reached (${p}/${A} devices). If you upgraded or changed your device, please visit ${V} for assistance.`};const u=await(await fetch("https://api.gumroad.com/v2/licenses/verify",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({product_id:N,product_permalink:a,license_key:e,increment_uses_count:"true"})})).json();if(u&&u.success===!0){const y=typeof u.uses=="number"?u.uses:p+1;return await g({isPro:!0,proLicenseKey:e}),{success:!0,message:`🎉 OfficeMate Pro Lifetime License Activated! (Device ${y} of ${A})`}}else return{success:!1,message:`❌ Activation failed: ${(u==null?void 0:u.message)||"Could not complete device registration."}`}}catch(c){return{success:!1,message:`Could not connect to Gumroad license server (${(c==null?void 0:c.message)||"Check your connection"}).`}}}function P(n,a,e){const s=a.recipientName||"Team",i=e.userFullName||"Best",r=e.userJobTitle||"",c=`

Best regards,
${i}${r?`
${r}`:""}`;switch(n){case"polite_pushback":return`Hi ${s},

Thank you for reaching out and sharing the updated requirements.

While I understand the urgency of this deliverable, our team is currently committed to existing high-priority milestones. Taking on this additional scope at this time would compromise the quality and delivery schedule of our core commitments.

I recommend we either:
1. Schedule this for our upcoming sprint/cycle starting next week, or
2. Re-prioritize our current backlog so we can allocate dedicated focus.

Let me know which option aligns best with your roadmap.${c}`;case"executive_status":return`Hi ${s},

Please find below our weekly executive status update:

• Completed Deliverables:
  - Finalized system review and stakeholder alignment.
  - Resolved all critical path items for the current phase.

• Currently In Progress:
  - Quality assurance testing and documentation wrap-up.
  - Coordinating with cross-functional partners for deployment.

• Blockers & Risks:
  - None at this time. All milestones remain on track.

• Next Steps:
  - Review meeting scheduled for Thursday to finalize launch readiness.

Please let me know if you require any additional metrics or details.${c}`;case"formal_confirmation":return`Hi ${s},

Thank you for the productive discussion. 

I am writing to formally confirm our alignment on the agreed action items and timeline:
• Scope: ${a.keyPoints||"As discussed in our meeting"}
• Target Delivery Date: ${a.deadline||"End of week"}

Our team has initiated the next steps and we will share progress checkpoints accordingly. If there are any revisions needed, please feel free to flag them by EOD tomorrow.${c}`;case"friendly_followup":return`Hi ${s},

Hope you are having a productive week!

I wanted to quickly circle back regarding our previous discussion on ${a.keyPoints||"the project proposal"}. 

When you have a moment, could you please share a quick update or let me know if you need any additional inputs from my end to move forward?

Looking forward to hearing from you.${c}`;case"meeting_reschedule":return`Hi ${s},

I hope you are doing well.

Due to an unavoidable scheduling conflict with an executive client briefing, I will need to request rescheduling our meeting scheduled for today.

Would any of the following alternate time slots work on your calendar?
• Tomorrow at 11:00 AM EST
• Thursday at 2:30 PM EST
• Friday at 10:00 AM EST

My sincere apologies for any inconvenience this may cause, and thank you for your flexibility.${c}`;default:return`Hi ${s},

Thank you for the update. Everything looks aligned from our perspective.

Please let me know if you need any further assistance.${c}`}}async function ne(n,a,e){var i,r,c,d,p,h,u,y;if(e.aiProvider==="offline"||!e.aiApiKey)return P(n,a,e);const s=`You are OfficeMate, an expert Microsoft 365 executive email assistant.
Write a professional corporate email response.
Tone: ${n.replace("_"," ").toUpperCase()}
Sender: ${e.userFullName} (${e.userJobTitle} at ${e.companyName})
Recipient: ${a.recipientName||"Colleague / Client"}
Context / Incoming Email:
"${a.incomingText||"Follow up on project status"}"
Key Points to Include:
"${a.keyPoints||"Confirm timeline and align on next steps"}"

Guidelines:
- Clear, concise, executive tone.
- Professional corporate etiquette.
- Include a polite sign-off with the sender's name and title.`;try{if(e.aiProvider==="openai"){const m=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e.aiApiKey}`},body:JSON.stringify({model:e.aiModel||"gpt-4o-mini",messages:[{role:"user",content:s}],temperature:.3})});if(!m.ok)throw new Error(m.statusText);return((c=(r=(i=(await m.json()).choices)==null?void 0:i[0])==null?void 0:r.message)==null?void 0:c.content)||P(n,a,e)}if(e.aiProvider==="gemini"){const m=e.aiModel||"gemini-1.5-flash",w=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${e.aiApiKey}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:s}]}]})});if(!w.ok)throw new Error(w.statusText);return((y=(u=(h=(p=(d=(await w.json()).candidates)==null?void 0:d[0])==null?void 0:p.content)==null?void 0:h.parts)==null?void 0:u[0])==null?void 0:y.text)||P(n,a,e)}}catch(m){return console.warn("AI API call failed, falling back to corporate template",m),P(n,a,e)}return P(n,a,e)}document.addEventListener("DOMContentLoaded",async()=>{let n=await b();const a=document.getElementById("plan-badge"),e=document.getElementById("stash-name-input"),s=document.getElementById("btn-popup-stash"),i=document.getElementById("popup-workspaces-list"),r=document.getElementById("workspaces-count"),c=document.getElementById("draft-tone-select"),d=document.getElementById("draft-notes-input"),p=document.getElementById("btn-popup-generate"),h=document.getElementById("draft-copied-msg"),u=document.getElementById("setting-name"),y=document.getElementById("setting-title"),m=document.getElementById("setting-ai-provider"),w=document.getElementById("group-api-key"),v=document.getElementById("setting-api-key"),C=document.getElementById("setting-license-key"),G=document.getElementById("btn-activate-pro"),W=document.getElementById("btn-open-inpage-sidebar"),T=document.getElementById("banner-buy-pro"),O=document.getElementById("custom-modal-backdrop"),q=document.getElementById("modal-icon"),j=document.getElementById("modal-title"),H=document.getElementById("modal-message"),x=document.getElementById("modal-btn-close"),$=document.getElementById("modal-btn-ok"),z=document.getElementById("modal-btn-pro"),S=document.getElementById("popup-toast");function E(t){q.textContent=t.icon||"ℹ️",j.textContent=t.title,H.textContent=t.message,z.style.display=t.showProBtn?"inline-flex":"none",O.style.display="flex";const o=()=>{O.style.display="none",x.removeEventListener("click",o),$.removeEventListener("click",o),t.onClose&&t.onClose()};x.addEventListener("click",o),$.addEventListener("click",o)}function D(t){S.textContent=t,S.style.display="block",setTimeout(()=>{S.style.display="none"},2500)}function M(){n.isPro?(a.className="badge-pro",a.textContent="👑 PRO",T&&(T.style.display="none")):(a.className="badge-free",a.textContent="FREE",T&&(T.style.display="flex"))}M();const _=document.querySelectorAll(".tab-btn"),J=document.querySelectorAll(".tab-panel");_.forEach(t=>{t.addEventListener("click",()=>{var l;_.forEach(f=>f.classList.remove("active")),J.forEach(f=>f.classList.remove("active")),t.classList.add("active");const o=t.getAttribute("data-tab");(l=document.getElementById(`panel-${o}`))==null||l.classList.add("active")})}),s.addEventListener("click",()=>{const t=e.value.trim()||`Workspace ${new Date().toLocaleDateString()}`;s.disabled=!0,chrome.runtime.sendMessage({action:"STASH_TABS",name:t},o=>{var l;s.disabled=!1,o!=null&&o.success?(e.value="",L(),D(`Stashed ${o.count||"all"} tabs!`)):E({title:"Workspace Notice",icon:"⚠️",message:(o==null?void 0:o.message)||"Could not stash workspace.",showProBtn:!!((l=o==null?void 0:o.message)!=null&&l.includes("Pro"))})})});async function L(){const t=await U();if(r.textContent=String(t.length),t.length===0){i.innerHTML='<div style="text-align: center; color: #64748b; font-size: 12px; padding: 20px 0;">No saved workspaces yet.</div>';return}i.innerHTML=t.map(o=>`
      <div class="workspace-item" data-id="${o.id}">
        <div>
          <strong style="color: #f8fafc; font-size: 12.5px; display: block;">${o.name}</strong>
          <span style="color: #94a3b8; font-size: 11px;">${o.tabs.length} tabs</span>
        </div>
        <div style="display: flex; gap: 4px;">
          <button class="action-btn primary btn-restore" style="padding: 4px 8px; font-size: 11px;">🚀 Open</button>
          <button class="action-btn btn-del" style="padding: 4px 8px; font-size: 11px; color: #ef4444;">✕</button>
        </div>
      </div>
    `).join(""),i.querySelectorAll(".btn-restore").forEach((o,l)=>{o.addEventListener("click",()=>{const f=t[l];chrome.runtime.sendMessage({action:"RESTORE_WORKSPACE",tabs:f.tabs}),window.close()})}),i.querySelectorAll(".btn-del").forEach((o,l)=>{o.addEventListener("click",async()=>{const f=t[l];await ee(f.id),L()})})}L(),p.addEventListener("click",async()=>{const{allowed:t}=await X();if(!t){E({title:"Daily Limit Reached",icon:"👑",message:`Daily free email draft limit (3 drafts) reached!

Upgrade to OfficeMate Pro for unlimited drafts, tab workspaces, and priority AI features.`,showProBtn:!0});return}p.disabled=!0,p.textContent="Generating...";const o=c.value,l=d.value.trim(),f=await ne(o,{incomingText:l},n);await Z(),navigator.clipboard.writeText(f),p.disabled=!1,p.textContent="⚡ Generate & Copy Draft",h.style.display="block",setTimeout(()=>{h.style.display="none"},3e3)}),u.value=n.userFullName||"",y.value=`${n.userJobTitle||""}${n.companyName?`, ${n.companyName}`:""}`,m.value=n.aiProvider||"offline",v.value=n.aiApiKey||"";const k=document.getElementById("api-key-link"),R=()=>{const t=m.value==="offline";w.style.display=t?"none":"block",k&&(m.value==="openai"?(k.href="https://platform.openai.com/api-keys",k.textContent="Get OpenAI Key ↗",v.placeholder="sk-..."):m.value==="gemini"&&(k.href="https://aistudio.google.com/app/apikey",k.textContent="Get Gemini Key ↗",v.placeholder="AIzaSy..."))};R(),m.addEventListener("change",async()=>{R(),await g({aiProvider:m.value})}),u.addEventListener("change",async()=>{await g({userFullName:u.value.trim()})}),y.addEventListener("change",async()=>{var l,f;const o=y.value.trim().split(",");await g({userJobTitle:((l=o[0])==null?void 0:l.trim())||"",companyName:((f=o[1])==null?void 0:f.trim())||""})}),v.addEventListener("change",async()=>{await g({aiApiKey:v.value.trim()})}),G.addEventListener("click",async()=>{const t=C.value.trim();if(!t)return;const o=await te(t);o.success?(n=await b(),M(),C.value="",E({title:"Pro Activated",icon:"🎉",message:o.message})):E({title:"Activation Failed",icon:"❌",message:o.message,showProBtn:!0})}),W.addEventListener("click",async()=>{const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!(t!=null&&t.id)||!t.url){D("No active tab detected.");return}if(t.url.startsWith("chrome://")||t.url.startsWith("edge://")||t.url.startsWith("about:")||t.url.includes("microsoftedge.microsoft.com")||t.url.includes("chrome.google.com/webstore")){E({title:"Page Not Supported",icon:"⚠️",message:`OfficeMate Copilot cannot run on internal browser pages (edge:// or web store pages).

Please navigate to a regular web page (e.g. Outlook, Teams, Google, or any website) to use the sidebar.`});return}chrome.tabs.sendMessage(t.id,{action:"TOGGLE_SIDEBAR"},l=>{chrome.runtime.lastError||!(l!=null&&l.success)?chrome.scripting.executeScript({target:{tabId:t.id},files:["content.js"]},()=>{setTimeout(()=>{chrome.tabs.sendMessage(t.id,{action:"TOGGLE_SIDEBAR"}),window.close()},120)}):window.close()})})});
